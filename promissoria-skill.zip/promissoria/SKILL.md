---
name: promissoria
description: Emitir notas promissórias da fazenda em PDF, gerar termo de quitação/cancelamento após o pagamento e sincronizar tudo na Base CFAgro (Supabase), vinculado ao lote/negócio do painel. Use quando o usuário pedir para "emitir promissória", "gerar nota promissória", "quitar/cancelar promissória", "recebi o pagamento da promissória" ou "listar promissórias".
---

# Promissória — emissão, quitação e registro (CFAgro)

Script: `scripts/promissoria.py` (Python 3; deps: `fpdf2`, `num2words` — ver `requirements.txt`).
Dados em `$PROMISSORIA_HOME` (padrão `~/promissorias`): `config.json`, `registro.json` (cópia local), `pdfs/`.
Fonte de verdade: tabela `promissorias` na Base CFAgro (Supabase) — upsert automático em cada emissão/quitação.

## Setup (primeira vez)

1. Copie `config.example.json` para `~/promissorias/config.json` (emitente, praça padrão, Supabase já apontado para a Base CFAgro).
2. Rode `promissorias.sql` uma vez no SQL Editor do Supabase para criar a tabela (ajuste as policies de RLS ao padrão do painel).
3. Exporte a chave: `SUPABASE_SERVICE_KEY` no ambiente do agente (service role ou chave com insert/update em `promissorias`).

## Emitir

Colete do usuário: credor (nome + CPF), valor, vencimento, praça (senão usa a padrão) e, se houver, o ID do lote/negócio no painel. Depois:

```bash
python3 scripts/promissoria.py emitir \
  --credor "Francisco Carlos de Oliveira Rosa" --cpf-credor 178.918.091-00 \
  --valor 555468.93 --vencimento 13/05/2026 --negocio DEAL-123
```

Retorna JSON com número sequencial (NNN/AAAA), caminho do PDF e status da sincronização com a Base CFAgro.
**Sempre lembre o usuário**: o PDF deve ser assinado digitalmente no gov.br (https://assinador.iti.br) antes de enviar ao credor. Envie o PDF ao usuário/conversa.

## Quitar (após pagamento)

Confirme com o usuário a data e a forma de pagamento (Pix/TED etc.). Se os dados do pagamento chegarem via Telegram (ou o wey trouxer da conversa de WhatsApp), proponha os campos extraídos, mas peça confirmação antes de gerar. Depois:

```bash
python3 scripts/promissoria.py quitar \
  --numero 001/2026 --data-pagamento 10/05/2026 --forma "Pix"
```

Gera o Termo de Quitação e Cancelamento (PDF), marca a nota como quitada e atualiza a Base CFAgro (o painel reflete na hora).
**Sempre lembre o usuário**: quem assina a quitação é o CREDOR (ideal via gov.br); anexar o comprovante e pedir devolução/inutilização da via original da promissória.

## Listar / conferir

```bash
python3 scripts/promissoria.py listar --status aberta
```

Use para conferir vencimentos próximos e números já emitidos.

## Regras

- Nunca emita nem quite sem confirmação explícita do usuário dos campos (valor, CPF, datas).
- Não invente ID de lote/negócio: se o usuário não informar, emita sem `--negocio`.
- Se a sincronização com a Base CFAgro falhar, o PDF e o registro local continuam válidos — avise o usuário e tente sincronizar de novo depois.
- A promissória deve conter promessa incondicional de pagamento — não aceite pedidos de cláusulas condicionais no corpo do título; condições vão em contrato à parte.
- Erros do script saem em stderr com mensagem clara (ex.: config incompleta, número duplicado); repasse ao usuário.
