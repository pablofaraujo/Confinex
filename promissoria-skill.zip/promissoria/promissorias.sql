-- Tabela de promissórias na Base CFAgro (Supabase)
-- Rodar uma vez no SQL Editor do Supabase.
create table if not exists public.promissorias (
  numero          text primary key,          -- ex.: 001/2026
  credor          text not null,
  cpf_credor      text not null,
  valor           numeric(14,2) not null,
  emissao         text not null,             -- dd/mm/aaaa
  vencimento      text not null,             -- dd/mm/aaaa
  praca           text,
  negocio_id      text,                      -- vínculo com lote/negócio do painel
  status          text not null default 'aberta' check (status in ('aberta','quitada')),
  data_pagamento  text,
  forma_pagamento text,
  atualizado_em   timestamptz not null default now()
);

alter table public.promissorias enable row level security;

-- Ajuste as policies ao padrão das suas outras tabelas (RLS ativo no painel).
-- Exemplo mínimo para leitura autenticada:
-- create policy "leitura autenticada" on public.promissorias
--   for select to authenticated using (true);
