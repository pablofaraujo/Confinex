#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Emissao e quitacao de notas promissorias em PDF.

Uso:
  promissoria.py emitir --credor "Nome" --cpf-credor 000.000.000-00 \
      --valor 555468.93 --vencimento 13/05/2026 [--praca "Sobralia-MG"] \
      [--negocio DEAL-123] [--numero 001/2026]

  promissoria.py quitar --numero 001/2026 --data-pagamento 10/05/2026 \
      --forma "Pix" [--comprovante caminho.pdf]

  promissoria.py listar [--status aberta|quitada]

Dados: PROMISSORIA_HOME (padrao ~/promissorias)
  config.json   -> dados do emitente, praca padrao, webhook do dashboard
  registro.json -> historico de todas as notas
  pdfs/         -> PDFs gerados
"""
import argparse, json, os, sys, re, unicodedata
from datetime import datetime, date
from pathlib import Path

from fpdf import FPDF
from num2words import num2words

HOME = Path(os.environ.get("PROMISSORIA_HOME", Path.home() / "promissorias"))
CONFIG = HOME / "config.json"
REGISTRO = HOME / "registro.json"
PDFS = HOME / "pdfs"

MESES = ["janeiro", "fevereiro", "marco", "abril", "maio", "junho",
         "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]
MESES_ACENTO = ["janeiro", "fevereiro", "março", "abril", "maio", "junho",
                "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]


def latin1(s):
    """fpdf core fonts sao latin-1; troca o que nao couber."""
    s = s.replace("—", "-").replace("–", "-")
    s = s.replace("“", '"').replace("”", '"').replace("’", "'")
    return s.encode("latin-1", "replace").decode("latin-1")


def parse_data(s):
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    raise SystemExit(f"Data invalida: {s} (use dd/mm/aaaa)")


def data_longa(d):
    return f"{d.day} de {MESES_ACENTO[d.month - 1]} de {d.year}"


def data_extenso(d):
    dia = num2words(d.day, lang="pt_BR")
    ano = num2words(d.year, lang="pt_BR")
    return f"{dia.capitalize()} de {MESES_ACENTO[d.month - 1].capitalize()} de {ano}"


def valor_fmt(v):
    s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R$ {s}"


def valor_extenso(v):
    return num2words(round(v, 2), lang="pt_BR", to="currency")


def load(path, default):
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return default


def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def config():
    cfg = load(CONFIG, {})
    faltando = [k for k in ("emitente_nome", "emitente_cpf") if not cfg.get(k)]
    if faltando:
        raise SystemExit(f"Preencha {CONFIG}: faltam {', '.join(faltando)}")
    return cfg


def proximo_numero(reg, ano):
    seq = [int(m.group(1)) for n in reg
           if (m := re.match(r"^(\d+)/(\d+)$", n["numero"])) and int(m.group(2)) == ano]
    return f"{(max(seq) + 1) if seq else 1:03d}/{ano}"


def slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")


def sync_supabase(cfg, registro_nota):
    """Upsert da nota na Base CFAgro (Supabase/PostgREST), chave = numero."""
    url = cfg.get("supabase_url")
    key = os.environ.get(cfg.get("supabase_key_env", "SUPABASE_KEY"), "")
    if not url or not key:
        return ("base CFAgro nao sincronizada: configure supabase_url em config.json "
                f"e exporte {cfg.get('supabase_key_env', 'SUPABASE_KEY')}")
    tabela = cfg.get("supabase_table", "promissorias")
    campos = {k: registro_nota.get(k) for k in
              ("numero", "credor", "cpf_credor", "valor", "emissao", "vencimento",
               "praca", "negocio_id", "status", "data_pagamento", "forma_pagamento")}
    import urllib.request
    req = urllib.request.Request(
        f"{url.rstrip('/')}/rest/v1/{tabela}?on_conflict=numero",
        data=json.dumps([campos], ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json", "apikey": key,
                 "Authorization": f"Bearer {key}",
                 "Prefer": "resolution=merge-duplicates,return=minimal"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return f"base CFAgro sincronizada (HTTP {r.status})"
    except Exception as e:
        return f"AVISO: falha ao sincronizar base CFAgro: {e}"


# ---------------------------------------------------------------- PDF helpers
class Doc(FPDF):
    def corpo(self, txt, bold=False, size=11, after=4, align="J"):
        self.set_font("helvetica", "B" if bold else "", size)
        self.multi_cell(0, 6, latin1(txt), align=align)
        self.ln(after)


def pdf_promissoria(n, cfg, caminho):
    pdf = Doc(format="A4")
    pdf.set_margins(25, 25, 25)
    pdf.add_page()
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 8, "NOTA PROMISSÓRIA".encode("latin-1", "replace").decode("latin-1"),
             align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(8)
    pdf.corpo(f"Nº {n['numero']}", bold=True)
    venc = parse_data(n["vencimento"])
    emissao = parse_data(n["emissao"])
    pdf.corpo(f"Vencimento: {data_longa(venc)}.", bold=True)
    pdf.corpo(f"{valor_fmt(n['valor'])} ({valor_extenso(n['valor'])})", bold=True)
    pdf.ln(2)
    pdf.corpo(
        f"No dia {data_longa(venc)} ({data_extenso(venc)}) pagar por esta única via de "
        f"nota promissória na praça de {n['praca']} a {n['credor']}, inscrito(a) no CPF "
        f"nº {n['cpf_credor']}, a quantia de {valor_fmt(n['valor'])} em moeda corrente deste país.")
    pdf.ln(4)
    pdf.corpo(f"{data_longa(emissao)}, {n['praca']}.")
    pdf.ln(16)
    pdf.corpo("______________________________", after=1, align="L")
    pdf.corpo(cfg["emitente_nome"], bold=True, after=1, align="L")
    pdf.corpo(f"CPF: {cfg['emitente_cpf']}", align="L")
    pdf.output(str(caminho))


def pdf_quitacao(n, cfg, caminho):
    pag = parse_data(n["data_pagamento"])
    emissao = parse_data(n["emissao"])
    venc = parse_data(n["vencimento"])
    hoje = date.today()
    pdf = Doc(format="A4")
    pdf.set_margins(25, 25, 25)
    pdf.add_page()
    pdf.set_font("helvetica", "B", 13)
    pdf.multi_cell(0, 7, latin1("TERMO DE QUITAÇÃO E CANCELAMENTO DE NOTA PROMISSÓRIA"), align="C")
    pdf.ln(8)
    pdf.corpo(f"CREDOR: {n['credor'].upper()}, inscrito(a) no CPF sob o nº {n['cpf_credor']}.")
    pdf.corpo(f"DEVEDOR/EMITENTE: {cfg['emitente_nome'].upper()}, inscrito(a) no CPF sob o nº {cfg['emitente_cpf']}.")
    pdf.ln(2)
    pdf.corpo(
        f"Pelo presente instrumento, o CREDOR acima qualificado declara, para todos os fins de "
        f"direito, que recebeu do DEVEDOR a quantia integral de {valor_fmt(n['valor'])} "
        f"({valor_extenso(n['valor'])}), referente à Nota Promissória nº {n['numero']}, emitida em "
        f"{data_longa(emissao)}, na praça de {n['praca']}, com vencimento em {data_longa(venc)}.")
    pdf.corpo(
        f"O pagamento foi realizado em {pag.strftime('%d/%m/%Y')}, por meio de {n['forma_pagamento']}, "
        f"conforme comprovante que integra o presente termo como anexo.")
    pdf.corpo(
        "Em razão do pagamento integral ora confirmado, o CREDOR dá ao DEVEDOR plena, geral, "
        "irrevogável e irretratável quitação da obrigação representada pela referida nota promissória, "
        "nos termos dos artigos 319 a 324 do Código Civil, nada mais havendo a reclamar, a qualquer "
        "título, em relação ao título ora quitado.")
    pdf.corpo(
        f"Fica a referida Nota Promissória nº {n['numero']} declarada QUITADA, CANCELADA E SEM NENHUM "
        "EFEITO, obrigando-se o CREDOR a não negociá-la, endossá-la, protestá-la ou executá-la, e a "
        "inutilizar ou restituir ao DEVEDOR todas as vias e cópias do título em seu poder, inclusive "
        "arquivos eletrônicos.")
    pdf.corpo(
        "O CREDOR declara, ainda, que o título não foi endossado, cedido, transferido ou dado em "
        "garantia a terceiros, respondendo civilmente por qualquer utilização indevida do título após "
        "a assinatura deste termo.")
    pdf.corpo(
        "Este termo é firmado em caráter definitivo, valendo como prova plena de quitação, e poderá "
        "ser assinado eletronicamente, com fundamento no art. 10, § 2º, da MP nº 2.200-2/2001 e na "
        "Lei nº 14.063/2020, reconhecendo as partes a validade jurídica das assinaturas eletrônicas apostas.")
    pdf.ln(6)
    pdf.corpo(f"{n['praca']}, {data_longa(hoje)}.", align="L")
    pdf.ln(12)
    for nome, cpf, papel in ((n["credor"], n["cpf_credor"], "Credor"),
                             (cfg["emitente_nome"], cfg["emitente_cpf"], "Devedor/Emitente")):
        pdf.corpo("_________________________________________________", after=1, align="C")
        pdf.corpo(nome.upper(), bold=True, after=1, align="C")
        pdf.corpo(f"CPF: {cpf} - {papel}", after=10, align="C")
    pdf.corpo("TESTEMUNHAS:", bold=True, align="L")
    pdf.corpo("1. ____________________________________  Nome: ______________________  CPF: ______________", align="L", after=6)
    pdf.corpo("2. ____________________________________  Nome: ______________________  CPF: ______________", align="L")
    pdf.output(str(caminho))


# ------------------------------------------------------------------ comandos
def cmd_emitir(a):
    cfg = config()
    reg = load(REGISTRO, [])
    emissao = parse_data(a.emissao) if a.emissao else date.today()
    numero = a.numero or proximo_numero(reg, emissao.year)
    if any(x["numero"] == numero for x in reg):
        raise SystemExit(f"Nota {numero} já existe no registro.")
    n = {
        "numero": numero,
        "credor": a.credor, "cpf_credor": a.cpf_credor,
        "valor": float(a.valor),
        "emissao": emissao.strftime("%d/%m/%Y"),
        "vencimento": parse_data(a.vencimento).strftime("%d/%m/%Y"),
        "praca": a.praca or cfg.get("praca_padrao", ""),
        "negocio_id": a.negocio,
        "status": "aberta",
        "criada_em": datetime.now().isoformat(timespec="seconds"),
    }
    PDFS.mkdir(parents=True, exist_ok=True)
    caminho = PDFS / f"NP_{numero.replace('/', '-')}_{slug(a.credor)}.pdf"
    pdf_promissoria(n, cfg, caminho)
    n["pdf"] = str(caminho)
    reg.append(n)
    save(REGISTRO, reg)
    hook = sync_supabase(cfg, n)
    print(json.dumps({"ok": True, "numero": numero, "pdf": str(caminho),
                      "negocio_id": a.negocio, "base_cfagro": hook,
                      "lembrete": "Assinar o PDF digitalmente em https://assinador.iti.br (gov.br)."},
                     ensure_ascii=False, indent=2))


def cmd_quitar(a):
    cfg = config()
    reg = load(REGISTRO, [])
    n = next((x for x in reg if x["numero"] == a.numero), None)
    if not n:
        raise SystemExit(f"Nota {a.numero} não encontrada. Use 'listar'.")
    if n["status"] == "quitada":
        raise SystemExit(f"Nota {a.numero} já está quitada ({n.get('data_pagamento')}).")
    n["data_pagamento"] = parse_data(a.data_pagamento).strftime("%d/%m/%Y")
    n["forma_pagamento"] = a.forma
    if a.comprovante:
        n["comprovante"] = a.comprovante
    caminho = PDFS / f"Quitacao_NP_{n['numero'].replace('/', '-')}_{slug(n['credor'])}.pdf"
    pdf_quitacao(n, cfg, caminho)
    n["status"] = "quitada"
    n["pdf_quitacao"] = str(caminho)
    n["quitada_em"] = datetime.now().isoformat(timespec="seconds")
    save(REGISTRO, reg)
    hook = sync_supabase(cfg, n)
    print(json.dumps({"ok": True, "numero": n["numero"], "pdf_quitacao": str(caminho),
                      "base_cfagro": hook,
                      "lembrete": "Quem assina a quitação é o CREDOR (ideal: gov.br). "
                                  "Anexe o comprovante do pagamento e peça a devolução/inutilização da via original."},
                     ensure_ascii=False, indent=2))


def cmd_listar(a):
    reg = load(REGISTRO, [])
    if a.status:
        reg = [x for x in reg if x["status"] == a.status]
    print(json.dumps(reg, ensure_ascii=False, indent=2))


def main():
    ap = argparse.ArgumentParser(description="Notas promissórias: emissão, quitação e registro.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    e = sub.add_parser("emitir")
    e.add_argument("--credor", required=True)
    e.add_argument("--cpf-credor", required=True)
    e.add_argument("--valor", required=True, type=float)
    e.add_argument("--vencimento", required=True)
    e.add_argument("--emissao", help="padrão: hoje")
    e.add_argument("--praca")
    e.add_argument("--negocio", help="ID do negócio no dashboard")
    e.add_argument("--numero", help="padrão: sequencial NNN/AAAA")
    e.set_defaults(f=cmd_emitir)

    q = sub.add_parser("quitar")
    q.add_argument("--numero", required=True)
    q.add_argument("--data-pagamento", required=True)
    q.add_argument("--forma", required=True, help='ex.: "Pix", "TED Banco X ag/conta"')
    q.add_argument("--comprovante")
    q.set_defaults(f=cmd_quitar)

    l = sub.add_parser("listar")
    l.add_argument("--status", choices=["aberta", "quitada"])
    l.set_defaults(f=cmd_listar)

    a = ap.parse_args()
    a.f(a)


if __name__ == "__main__":
    main()
